<?php
    define('EMAILID',"1nt19cs023.akshay@nmit.ac.in");
    define('PASSWORD', 'nitte123');
    define('EMAILID2',"msakshay2001@gmail.com");    
?>